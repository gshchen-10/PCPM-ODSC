package utils.ODSCluster;

import java.util.ArrayList;
import java.util.BitSet;

public class ODSCluster {
	
	public ArrayList<DPoint> dataset;
	
	public ODSCluster(ArrayList<DPoint> allPoint) {
		
		dataset = allPoint;
		
	}
	
	public ArrayList<NaiveCluster> Cluster(double eps, int minPts, float eta) {
				
		ArrayList<BitSet> levels= new ArrayList<>();
		int noiseCount = 0;

		BitSet level0 = new BitSet();
		for (int k = 0; k < dataset.size() - 1; k++) {
			if (dataset.get(k + 1).data - dataset.get(k).data <= eps) {
				level0.set(k + 1, true);
			} else {
				level0.set(k + 1, false);
				if (!level0.get(k))
					noiseCount++;
			}
		}
		levels.add(level0);
		if (noiseCount/(float)dataset.size() <= eta) {
			for (int i = 2; i < dataset.size(); i++) {
				BitSet level = new BitSet();
				for (int k = 0; k < dataset.size() - i; k++) {
					if (levels.get(i-2).get(k + i) == false || levels.get(i-2).get(k + i - 1) == false) {
						level.set(k + i, false);
						continue;
					}
					if (dataset.get(k + i).data - dataset.get(k).data <= eps) {
						level.set(k + i, true);
					} else {
						level.set(k + i, false);
					}
				}				
				if (level.cardinality() == 0) {
					break;
				}
				levels.add(level);
			}
		}  else {
			return null;
		}
		
		BitSet isCore = new BitSet();
		BitSet isNonNoise = new BitSet();

		for (int i = 0; i < dataset.size(); i++) {
			int neiCount = 1;
			for (int k = 0; k < levels.size(); k++) {
				if (levels.get(k).get(i))
					neiCount += 1;
				if (levels.get(k).get(k + i + 1))
					neiCount += 1;  
			}
			if (neiCount >= minPts) {
				isCore.set(i, true);
				isNonNoise.set(i, true);
				for (int k = 0; k < levels.size(); k++) {
					if (levels.get(k).get(i))
						isNonNoise.set(i - k - 1, true);
					if (levels.get(k).get(k + i + 1))
						isNonNoise.set(k + i + 1, true);
				}
			}
		}
		
		if ((dataset.size() - isNonNoise.cardinality()) / (float)dataset.size() > eta) {		
			return null;
		}
		
		ArrayList<NaiveCluster> clustIdToData = new ArrayList<>();
		int min = 0;
		int max = 0;
		for (int i = 0; i < dataset.size(); i++) {
			if (isCore.get(i)) {
				min = i;
				for (int k = levels.size() - 1; k >= 0; k--) {
					if (levels.get(k).get(i)) {
						min = i-k-1;
						break;
					}					
				}
				max = i;
				for (int k = levels.size() - 1; k >= 0; k--) {
					if (levels.get(k).get(k + i + 1)) {
						max = k + i + 1;
						break;
					}						
				}
				NaiveCluster newClust = new NaiveCluster(min, max);
				clustIdToData.add(newClust);
			}
		}

		for (int i = 0; i < clustIdToData.size() - 1; i++) {
			if (clustIdToData.get(i).max >= clustIdToData.get(i + 1).min) {
				clustIdToData.get(i).max = clustIdToData.get(i + 1).max;
				clustIdToData.remove(i + 1);
				i--;
			}
		}

		return clustIdToData;
		
	}

}
