package utils;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Order {
	
	public String orderId;
	public String orderDate;
	private ArrayList<Integer> ordProductsList = new ArrayList<>();	

	public Order() {
		
	}
	
	public Order(Order ord) {
		this.orderId = ord.orderId;
		this.orderDate = ord.orderDate;
		for (int i = 0; i < ord.ordProductsList.size(); i++)
			ordProductsList.add(ord.ordProductsList.get(i));
	}

	public Order(String ordid, String orddate, int prodid) {
		this.orderId = ordid;
		this.orderDate = orddate;
		addProduct(prodid);
	}

	public void addProduct(int productid) {
		this.ordProductsList.add(productid);
	}

	public ArrayList<Integer> getOrdProductsList(){
		return ordProductsList;
	}

	public void AddProductList(ArrayList<Integer> ordProdList) {
		for (int i = 0; i < ordProdList.size(); i++) {
			addProduct(ordProdList.get(i));
		}
	}
	
	public int getOrdProductsListSize(){
		return ordProductsList.size();
	}

	public int compareTo(Order arg0) {
		long flag = dateDifference(arg0);
		return (int)flag;
	}
	
	//�����������������ڲ�
	public long dateDifference(Order arg0) {
		long dateInterval = 0;
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		    ParsePosition pos1 = new ParsePosition(0);
		    ParsePosition pos2 = new ParsePosition(0);
		    Date dt1 = formatter.parse(this.orderDate, pos1);
		    Date dt2 = formatter.parse(arg0.orderDate, pos2);
		    long timeDiff = dt1.getTime() - dt2.getTime();
		    dateInterval = timeDiff / (1000 * 60 * 60 * 24);
		} catch(Exception e) {
			e.printStackTrace();
		}		
		return dateInterval;
	}

}
