package utils;

import java.text.ParseException;

public class PCPMiner {

	private RetailDatabase retailDatabase;
	private SeqVerticalDatabase seqVertDatabase;
	
	int pcps = 0;
	
	public PCPMiner(String inputFile) {
		retailDatabase = new RetailDatabase(inputFile);
		retailDatabase.Preprocessing();
	}

	public void Running(float coef, float noiRat, int eps, float minpts) throws ParseException {

		seqVertDatabase = new SeqVerticalDatabase(retailDatabase);
		pcps = seqVertDatabase.periodicClusterPatternMining(coef, noiRat, eps, minpts);
		
	}
	
	public void printStatistics(String dataset) {

		StringBuilder r = new StringBuilder(200);	
		r.append("===========  " + dataset + "  ============\n");
		r.append("Number of PCPs: ");
		r.append(pcps);	
		r.append("\n");	
		r.append("=================================\n");  

		System.out.println(r.toString());		
	}
}
