package utils.DBScanCluster;

public class NaiveCluster {
	
	public int max;
	public int min;
	
	public NaiveCluster(int min2, int max2) {
		this.min = min2;
		this.max = max2;
	}

}
