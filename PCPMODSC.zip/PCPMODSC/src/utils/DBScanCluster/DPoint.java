package utils.DBScanCluster;

public class DPoint {
	
	public int pts;  //number of points in MinPts
	public int cluster;
	public int inOrigId;
	public int inSortCoreId;
	public boolean visited;
	public int data;
	public String pointType; //[PointType_NOISE] [PointType_BORDER] [PointType_CORE]
	
	public DPoint() {
		init();
	}
	
	public DPoint(int aPoint) {
		this.data = aPoint;
		init();
	}
	
	private void init() {
		cluster = -1;
		pointType = "PointType_NOISE";
		pts = 0;
		visited = false;
		inOrigId = -1;
		inSortCoreId = 0;
	}

}
